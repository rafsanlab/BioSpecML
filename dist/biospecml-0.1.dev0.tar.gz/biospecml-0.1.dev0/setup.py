from distutils.core import setup

setup(
    name='biospecml',
    version='0.1dev',
    package_dir = {"": "src"},
    license='Creative Commons Attribution-Noncommercial-Share Alike license',
    long_description=open('README.md').read(),
)
